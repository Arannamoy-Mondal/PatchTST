Report 1.2 / v2.0 / Arannamoy / main

Each fold has four exact file lists.
inner_train: weight fitting during epoch selection.
inner_validation: speaker-level epoch selection.
outer_train: final refit, the union of inner train and validation.
outer_test: held-out OOF evaluation.

All paths are relative to the project root. No audio is included.
Catalogue roles: T = inner train, V = validation, E = test.
Final refit = T + V. Each of 773 files is test data once.
